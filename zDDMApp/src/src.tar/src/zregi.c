/**
 * @file    zregi.c
 * @author  J. Kuczewski 
 * @date    September 2015
 * @version 0.1
 * @brief   User application to perform register reads/writes over ZMQ to ZMQ<->UDP Server (zserver.c)
 */

#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>  
#include <errno.h>
#include <termio.h>
#include <termios.h>
#include "../include/reg_client.h"

// We have two operations: read and write
static const char *read_op  = "read";
static const char *write_op = "write";

int usage() {
    printf(  "regi [reb-id] read|write [<arguments>...]\n" \
             "  Numeric arguments may be in hex or decimal\n" \
             "Examples of usage:\n" \
             "  rri read 0x80ffff        -- read one register\n" \
             "  rri read 0x800000 5      -- read 5 registers starting at 0x800000\n" \
             "  rri write 0x800000 0     -- write 0 to register 0x800000\n" \
             "  rri write 0x800000 1 2 3 0xdecafbad\n" \
             "                           -- write 4 registers\n" \
             "\n");
    return -1;
}

int main(int argc, char* const argv[]) {

    if (argc < 3) return usage();

    uint32_t  id = strtoul(argv[1], NULL, 0);
    char     *operation  = argv[2];
    uint32_t  address = strtoul(argv[3], NULL, 0);
    int       rc = 0;

    char *ip_addr;
    ip_addr = getenv("ZREGI_IP_ADDR");
    if (ip_addr == NULL)
        ip_addr = "tcp://localhost";
    
    reg_client_t *reg = reg_client_new(ip_addr, id);
    if (reg == NULL)
        return -1;

    if (strncmp(operation, read_op, strlen(read_op)) &&
            strncmp(operation, write_op, strlen(write_op))) {
        return usage();
    }

    if (0 == strncmp(operation, read_op, strlen(read_op))) {
        // Syntax:
        // rri foo read addr
        // rri foo read addr count

        unsigned count = 1;

        if (argc > 4) count = strtoul(argv[4], NULL, 0);

        for (unsigned i = 0; i < count; ++i) {
            uint32_t a = address + i;
            uint32_t dat;
            
            rc = reg_client_read(reg, a, &dat);
            if (rc != 0) 
                printf("  Register 0x%x (%d): %s\n", a, a, reg_client_strerr(reg));
            else
                printf("  Register 0x%x (%d): 0x%08x (%i)\n", a, a, dat, dat);
        }
    } else if (0 == strncmp(operation, write_op, strlen(write_op))) {
        // Syntax:
        // rri foo write addr value
        // rri foo write addr value value ...

        for (int i = 0; i < (argc - 4); ++i) {
            uint32_t a = address + i;
            uint32_t val = strtoul(argv[i+4], NULL, 0);
            
            rc = reg_client_write(reg, a, val);
            if (rc != 0) {
                fprintf(stderr, "Error: %s, addr: 0x%x\n", reg_client_strerr(reg), a);
                return -1;
            }
        }
    }

    reg_client_close(reg);
    return 0;
}
