/**
 * @file    reg_client.c
 * @author  J. Kuczewski 
 * @date    September 2015
 * @version 0.1
 * @brief   Register read/write wrapper to ZMQ server.
 */

#include <zmq.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>
#include <pthread.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <stdbool.h>
#include "../include/reg_client.h"

reg_client_t *reg_client_new(char *ip_addr, int id)
{
    reg_client_t *ret;
    char tmp[512];
    
    ret = malloc(sizeof(reg_client_t));
    sprintf(tmp, "%s:554%i", ip_addr, id);
    ret->ctx   = zmq_ctx_new();
    ret->zsock = zmq_socket(ret->ctx, ZMQ_REQ);
    int timeout_ms = 3500;
    zmq_setsockopt(ret->zsock, ZMQ_RCVTIMEO, &timeout_ms, sizeof(int));
    zmq_connect(ret->zsock, tmp);
    
    return ret;
}

int reg_client_read(reg_client_t *rcli, uint32_t addr, uint32_t *value)
{
    int rc = 0;
    zmq_msg_t msg;
    uint32_t buff[3];
    uint32_t ret[2];
    char *errstr;
    
    // Send read and addr to server
    buff[0] = CMD_REG_READ;
    buff[1] = addr;
    buff[2] = 0x0;
    zmq_send(rcli->zsock, &buff[0], sizeof(uint32_t), ZMQ_SNDMORE);
    zmq_send(rcli->zsock, &buff[1], sizeof(uint32_t)*2, 0);
    
    // Recv 1st frame, switch on that for error or okay
    zmq_msg_init(&msg);
    rc = zmq_msg_recv(&msg, rcli->zsock, 0);
    if (rc < 0) {
        return -1;
    }
    uint32_t cmd = *(uint32_t *)zmq_msg_data(&msg);
    zmq_msg_close(&msg);
    
    int more;
    size_t more_size = sizeof(more);
    zmq_getsockopt(rcli->zsock, ZMQ_RCVMORE, &more, &more_size);
    
    if (cmd == CMD_ERROR) {
        zmq_msg_init(&msg);
        zmq_msg_recv(&msg, rcli->zsock, 0);
        errstr = ((char *)zmq_msg_data(&msg));
        strcpy(rcli->error_str, errstr);
        zmq_msg_close(&msg);
        
        return -1;
    }
    
    zmq_msg_init(&msg);
    zmq_msg_recv(&msg, rcli->zsock, 0);
    ret[0] = ((uint32_t *)zmq_msg_data(&msg))[0];
    ret[1] = ((uint32_t *)zmq_msg_data(&msg))[1];
    zmq_msg_close(&msg);
    
    if (ret[0] != addr) {
        return -1;
    }
    
    *value = ret[1];
    return 0;
}

int reg_client_write(reg_client_t *rcli, uint32_t addr, uint32_t value)
{
    int rc = 0;
    zmq_msg_t msg;
    uint32_t buff[3];
    uint32_t ret[2];
    char *errstr;
    
    // Send read and addr to server
    buff[0] = CMD_REG_WRITE;
    buff[1] = addr;
    buff[2] = value;
    zmq_send(rcli->zsock, &buff[0], sizeof(uint32_t), ZMQ_SNDMORE);
    zmq_send(rcli->zsock, &buff[1], sizeof(uint32_t)*2, 0);
    
    // Recv 1st frame, switch on that for error or okay
    zmq_msg_init(&msg);
    rc = zmq_msg_recv(&msg, rcli->zsock, 0);
    if (rc < 0) {
        return -1;
    }
    uint32_t cmd = *(uint32_t *)zmq_msg_data(&msg);
    zmq_msg_close(&msg);
    
    int more;
    size_t more_size = sizeof(more);
    zmq_getsockopt(rcli->zsock, ZMQ_RCVMORE, &more, &more_size);
    
    if (cmd == CMD_ERROR) {
        zmq_msg_init(&msg);
        zmq_msg_recv(&msg, rcli->zsock, 0);
        errstr = ((char *)zmq_msg_data(&msg));
        strcpy(rcli->error_str, errstr);
        zmq_msg_close(&msg);
        
        return -1;
    }
    
    zmq_msg_init(&msg);
    zmq_msg_recv(&msg, rcli->zsock, 0);
    ret[0] = ((uint32_t *)zmq_msg_data(&msg))[0];
    ret[1] = ((uint32_t *)zmq_msg_data(&msg))[1];
    zmq_msg_close(&msg);
    
    if (ret[0] != addr && ret[1] != buff[1]) {
        return -1;
    }
        
    return 0;
    
}

int reg_client_close(reg_client_t *rcli)
{
    int rc;
    rc = zmq_close(rcli->zsock);
    rc = zmq_ctx_destroy(rcli->ctx);
    return rc;
}

char *reg_client_strerr(reg_client_t *rcli)
{
    return rcli->error_str;
}

/*
int main(void)
{
    reg_client_t *reg = reg_client_new("tcp://192.168.11.4");
    int rc = 0;
    uint32_t val = 0;
    
    rc = reg_client_write(reg, 0xbeef, 0x3);
    if (rc < 0)
        printf("%s\n", reg_client_strerr(reg));
    
    rc = reg_client_read(reg, 0xbeef, &val);
    if (rc < 0)
        printf("%s\n", reg_client_strerr(reg));
    
    rc = reg_client_read(reg, 0x5, &val);
    if (rc < 0)
        printf("%s\n", reg_client_strerr(reg));
    
    printf("0x%x\n", val);
    
    reg_client_close(reg);
    return 0;
}*/