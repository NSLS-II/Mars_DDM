/**
 * @file    image_client.c
 * @author  J. Kuczewski 
 * @date    September 2015
 * @version 0.1
 * @brief   Low level UDP data access, saves to disk, for testing 
 *          NOT ZMQ!
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "../include/gige.h"

int main(void)
{
    FILE *fp;
    char filename[1024];
    
    gige_data_t *dat = gige_data_init(0x1, NULL);
    uint16_t *pixels = malloc(2020*550*16*3*4*4);
    
    while (1) {
        int size = gige_data_recv(dat, pixels);
        sprintf(filename, "%u.bin", (unsigned)time(NULL));  
        fp = fopen(filename, "w" );
        fwrite(pixels, gige_get_n_pixels(dat), sizeof(uint16_t), fp);
        printf("wrote %i bytes to %s (recv at %.3f MiB/s)\n", size, filename, gige_get_bitrate(dat));
        fclose(fp);
    }
    
    free(pixels);
    return 0;
}
