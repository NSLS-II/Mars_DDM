/**
 * @file    zserver.c
 * @author  J. Kuczewski 
 * @date    September 2015
 * @version 0.1
 * @brief   ZMQ serverto perform register reads/writes over UDP and 
 *          route data over ZMQ (currently disabled) 
 */

#include <zmq.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>
#include <pthread.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <stdbool.h>
#include "../include/gige.h"

#define CMD_REG_READ       0
#define CMD_REG_WRITE      1
#define CMD_ERROR          2
#define CMD_IMG_PARAMETERS 3

#define DEBUG 2

#ifdef DEBUG
 #if DEBUG == 1
    #define DBG_PRINT(fmt, args...) fprintf(stdout, fmt, ##args)
 #elif DEBUG == 2
   #define DBG_PRINT(fmt, args...) fprintf(stdout, " %s:%d:%s(): " fmt, \
    __FILE__, __LINE__, __func__, ##args)
  #endif
#else
 #define DBG_PRINT(fmt, args...) /* Don't do anything in release builds */
#endif

#define TOTAL_STRIPES 3
#define CHANNELS      16
#define STRIPE_ADDR   0x400007
#define SLEFT         0x1
#define SMIDDLE       0x2
#define SRIGHT        0x4

#define IFACE                 "eth0"
#define SYNCSERVICE_TCP       "tcp://*:5562"
#define PUB_TCP_PORT          5550
#define PUBLISHER_TCP         "tcp://*:%i"
#define PUBLISHER_IPC         "ipc://reb_%i.ipc"
#define CMD_TCP               "tcp://*:%i"
#define CHUNK_SIZE            250000
#define SUBSCRIBERS_EXPECTED  1

// Thread args for register task 
typedef struct {
    uint16_t id;
    char     *iface;
} reg_args_t;

#ifdef IMAGE_SERVICE 

// Stripe Structure
typedef struct {
    bool     enabled;
    int      idx;
    size_t   length;
    uint32_t height;
    uint32_t width;
    uint32_t *data;
    uint64_t tag;
    uint32_t cluster;
    uint32_t address;
} stripe_t;

// Thread args for fits file writer
typedef struct {
    stripe_t *current_stripe;
    char     *fname;
} stripe_args_t;

typedef struct {
    char            *iface;
    int              reb_id;
    uint8_t         *adc_buffer;             // Image buffer
    size_t           adc_buffer_length;       // Buffer length
    stripe_t         stripes[TOTAL_STRIPES];  // Allocate 3-Stripes
    pthread_mutex_t  stripe_lock;
    uint8_t          broadcast_data_ready_flag;
    gige_data_t     *data;
} image_t;

uint32_t img_height;
uint32_t img_width;
uint32_t stripes_en;

static int s_send (void *socket, char *string) {
    int size = zmq_send (socket, string, strlen (string), 0);
    return size;
}

void send_image(void *publisher, stripe_t *curr, char *topic_id)
{
    zmq_msg_t  topic;
    zmq_msg_t  msg;
    char       info_topic[2];
    uint32_t   info_data[6];
    const char char_i          = 'i';
    stripe_t   *current_stripe = curr;
    int        totsize         = current_stripe->length;
    int        pos             = 0;
    int        last            = 0;
    int        count           = 0;
    
    // Topic for info, append a `i` e.g. Ai
    memcpy(&info_topic[0], &topic_id, 1);
    memcpy(&info_topic[1], &char_i, 1);
    
    // Publish meta data about the dataset to follow
    memcpy(&info_data[0], &current_stripe->height,  sizeof(uint32_t));
    memcpy(&info_data[1], &current_stripe->width,   sizeof(uint32_t));
    memcpy(&info_data[2], &current_stripe->cluster, sizeof(uint32_t));
    memcpy(&info_data[3], &current_stripe->address, sizeof(uint32_t));
    memcpy(&info_data[4], &current_stripe->tag,     sizeof(uint64_t));
    
    zmq_msg_init_size(&topic, 2);
    memcpy(zmq_msg_data(&topic), &info_topic, 2);
    zmq_msg_init_size(&msg, sizeof(info_data));
    memcpy(zmq_msg_data(&msg), &info_data, sizeof(info_data));
    
    zmq_msg_send(&topic, publisher, ZMQ_SNDMORE);
    zmq_msg_send(&msg, publisher, 0);
    
    // Now publish the image data
    //printf("=>>> topic=%c pub=%p curr=%p\n", topic_id, publisher, curr);
    while (pos < totsize) {
        pos += CHUNK_SIZE;
        if (pos >= totsize)
            pos = totsize;
        count = pos - last;

        zmq_msg_init_size(&topic, 1);
        memcpy(zmq_msg_data(&topic), &topic_id, 1);

        zmq_msg_init_size(&msg, count*sizeof(uint32_t));
        memcpy(zmq_msg_data(&msg), &current_stripe->data[last], count*sizeof(uint32_t));
        
        zmq_msg_send(&topic, publisher, ZMQ_SNDMORE);
        zmq_msg_send(&msg, publisher, 0);

        last = pos;
    }
    zmq_msg_init_size(&topic, 1);
    memcpy(zmq_msg_data(&topic), &topic_id, 1);
    
    // Send trailer
    zmq_msg_send(&topic, publisher, ZMQ_SNDMORE);
    s_send(publisher, (char *)"END");
    
    zmq_msg_close(&topic);
    zmq_msg_close(&msg);
}

void *image_broadcaster(void *args)
{
    image_t *self = (image_t *)args;
    stripe_t *current_stripe;
    char     topic      = 'A';
    int      tcp_port   = PUB_TCP_PORT + self->reb_id;
    void     *context   = zmq_ctx_new();
    void     *publisher = zmq_socket(context, ZMQ_PUB);
    
    char pub_tcp_str[512];
    char ipc_str[512];
    
    sprintf(pub_tcp_str, PUBLISHER_TCP, tcp_port);
    sprintf(ipc_str, PUBLISHER_IPC, self->reb_id);

    DBG_PRINT("Listening on %s, %s\n", pub_tcp_str, ipc_str);
    int sndhwm = 0;
    zmq_setsockopt(publisher, ZMQ_SNDHWM, &sndhwm, sizeof(int));

    zmq_bind(publisher, pub_tcp_str);
    zmq_bind(publisher, ipc_str);
    
    while (1) {
        
        pthread_mutex_lock(&(self->stripe_lock));
        if (self->broadcast_data_ready_flag) {
            for (int i = 0; i < TOTAL_STRIPES; i++) {
                current_stripe = &(self->stripes[i]);
                if (current_stripe->enabled) {
            //        printf("*** Sending new data...curr=%p, publisher=%p\n", &(self->stripes[i]), &publisher);
                    send_image(publisher, &(self->stripes[i]), (char *)topic + (char)i);
                }
            }
            self->broadcast_data_ready_flag = 0;
        }
        pthread_mutex_unlock(&(self->stripe_lock));
    }

    zmq_close(publisher);
    zmq_ctx_destroy(context);
    
    pthread_exit(NULL);
}

uint32_t sign_extend_18bpp(uint32_t word) {
    uint32_t ret = (word & (1 << 17)) >> 17 ? word | 0xfffc0000 : word & 0x0003ffff;
    ret = (ret * -1) + 131072;
    return ret;
}

void *image_task(void *args)
{
    image_t *self = (image_t *)args;
    uint32_t img_word_cnt  = 0;
    int      stripe_select = 0;
    uint8_t  stripe_count  = 0;
    double bitrate = 0.0;
    stripe_t *current_stripe;
    struct timeval tvBegin, tvEnd, tvDiff;


    while (1) {
    img_word_cnt  = 0;
    stripe_select = 0;
    stripe_count  = 0;
    bitrate = 0.0;
    pthread_mutex_lock(&(self->stripe_lock));
    for (int i = 0; i < 3; i++) {
        self->stripes[i].enabled = false;
    }

    if (stripes_en & SLEFT)
        self->stripes[0].enabled = true;
    if (stripes_en & SMIDDLE)
        self->stripes[1].enabled = true;
    if (stripes_en & SRIGHT)
        self->stripes[2].enabled = true;
    
    for (int i = 0; i < TOTAL_STRIPES; i++) {
        if (self->stripes[i].enabled) {
            if (self->stripes[i].data == NULL) {
                self->stripes[i].data = malloc(img_height*img_width*CHANNELS*sizeof(uint32_t));
                DBG_PRINT("(%p) Added stripe %i at %p (%i bytes)\n", self, i, &(self->stripes[i]), img_height*img_width*CHANNELS*4);
            }
            
            self->stripes[i].length = 0;
            self->stripes[i].idx    = 0;
            self->stripes[i].height = img_height;
            self->stripes[i].width  = img_width;
            stripe_count++;
        }
    }
    
    current_stripe = &(self->stripes[stripe_select]);
    while (!current_stripe->enabled) {
        stripe_select = (stripe_select + 1) % TOTAL_STRIPES;
        current_stripe = &(self->stripes[stripe_select]);
    }

    // blocking call to recv data
    uint16_t *pixels = malloc(img_height*img_width*stripe_count*CHANNELS*sizeof(uint16_t));
    int size = gige_data_recv(self->data, pixels);
    if (size <= 0)
        goto bail; 
    
    if ((img_height*img_width*stripe_count*CHANNELS) != gige_get_n_pixels(self->data)) {
        DBG_PRINT("*** Unexpected length returned: npix=%i, alloc=%i, "\
                        "expected %i pix, %i bytes\n",
                gige_get_n_pixels(self->data), size,
                (img_height*img_width*stripe_count*CHANNELS), 
                (img_height*img_width*stripe_count*CHANNELS)*sizeof(uint32_t));
        //goto bail;
    }
        
    for (int i = 0; i < TOTAL_STRIPES; i++) {
        if (self->stripes[i].enabled) {
            self->stripes[i].tag     = 0x0;
            self->stripes[i].cluster = 0x0;
            self->stripes[i].address = 0x0;
        }
    }
        
    for (int i = 0; i < gige_get_n_pixels(self->data); i++) {
        if (img_word_cnt % CHANNELS == 0 && img_word_cnt > 0) {
            stripe_select = (stripe_select + 1) % TOTAL_STRIPES;
            current_stripe = &(self->stripes[stripe_select]);
            while (!current_stripe->enabled) {
                stripe_select = (stripe_select + 1) % TOTAL_STRIPES;
                current_stripe = &(self->stripes[stripe_select]);
            }
        } 
        uint32_t tmp_word = sign_extend_18bpp(htons(pixels[i]) << 2);
        img_word_cnt++;
        memcpy(&current_stripe->data[current_stripe->idx++], &tmp_word, sizeof(uint32_t));
        current_stripe->length++;
    }
    usleep(10);
    self->broadcast_data_ready_flag = 1;
    free(pixels);
bail:
    pthread_mutex_unlock(&(self->stripe_lock));
    usleep(10);
    }
}

#endif

static int zsend_error(void *socket, const char *msg) 
{
    uint32_t buf = CMD_ERROR;
    int rc = zmq_send(socket, &buf, sizeof(uint32_t), ZMQ_SNDMORE);
    rc = zmq_send(socket, msg, strlen(msg), 0);
    return rc;
}

void *register_task(void *args)
{
    reg_args_t *arg = (reg_args_t *)args;
    uint32_t buffer[3];
    
    void *context = zmq_ctx_new();
    void *responder = zmq_socket(context, ZMQ_REP);
    
    char tcp_str[512];
    sprintf(tcp_str, CMD_TCP, 5540 + arg->id);
    int rc = zmq_bind(responder, tcp_str);
    assert(rc == 0);
        
    DBG_PRINT("Listening on %s\n", tcp_str);
    
    gige_reg_t *reg = gige_reg_init(arg->id, arg->iface);
    if (reg == NULL)
        pthread_exit(NULL);
    
    while (1) {
        zmq_msg_t msg;
        zmq_msg_init (&msg);
        
        zmq_msg_recv(&msg, responder, 0);
        uint32_t cmd = *(uint32_t *)zmq_msg_data(&msg);
        zmq_msg_close(&msg);
        
        int more;
        size_t more_size = sizeof(more);
        zmq_getsockopt(responder, ZMQ_RCVMORE, &more, &more_size);
        
        uint32_t addr = 0;
        uint32_t value = 0;
        
        switch (cmd) {
            case CMD_REG_READ:
                // do read register
                
                zmq_msg_init(&msg);
                zmq_msg_recv(&msg, responder, 0);
                addr =  ((uint32_t *)zmq_msg_data(&msg))[0];
                value = ((uint32_t *)zmq_msg_data(&msg))[1];
                zmq_msg_close(&msg);
                
                rc = gige_reg_read(reg, addr, &value);
                if (rc != 0) {
                    zsend_error(responder, gige_strerr(rc));
                    //fprintf(stderr, "Error: %s, addr: 0x%x\n", gige_strerr(rc), addr);
                    break;
                }
                
                buffer[0] = cmd;
                buffer[1] = addr;
                buffer[2] = value;
                zmq_send(responder, &buffer[0], sizeof(uint32_t), ZMQ_SNDMORE);
                zmq_send(responder, &buffer[1], sizeof(uint32_t)*2, 0);
                break;
                
            case CMD_REG_WRITE:
                // do write
                
                zmq_msg_init(&msg);
                zmq_msg_recv(&msg, responder, 0);
                addr =  ((uint32_t *)zmq_msg_data(&msg))[0];
                value = ((uint32_t *)zmq_msg_data(&msg))[1];
                zmq_msg_close(&msg);
                
                rc = gige_reg_write(reg, addr, value);
                if (rc != 0) {
                    zsend_error(responder, gige_strerr(rc));
                   // fprintf(stderr, "Error: %s, addr: 0x%x\n", gige_strerr(rc), addr);
                    break;
                }
                
                buffer[0] = cmd;
                buffer[1] = addr;
                buffer[2] = value;
                zmq_send(responder, &buffer[0], sizeof(uint32_t), ZMQ_SNDMORE);
                zmq_send(responder, &buffer[1], sizeof(uint32_t)*2, 0);
                break;
                
            case CMD_IMG_PARAMETERS:
                // Height, width, stripes enabled
                
#ifdef IMAGE_SERVICE 
                zmq_msg_init(&msg);
                zmq_msg_recv(&msg, responder, 0);
                img_height = ((uint32_t *)zmq_msg_data(&msg))[0];
                img_width  = ((uint32_t *)zmq_msg_data(&msg))[1];
                stripes_en = ((uint32_t *)zmq_msg_data(&msg))[2];
                zmq_msg_close(&msg);
#endif    
                
                buffer[0] = cmd;
                buffer[1] = 0x0;
                buffer[2] = 0x0;
                zmq_send(responder, &buffer[0], sizeof(uint32_t), ZMQ_SNDMORE);
                zmq_send(responder, &buffer[1], sizeof(uint32_t)*2, 0);
                break;
                
            default:
                buffer[0] = 0xdead;
                buffer[1] = 0xdead;
                buffer[2] = 0xdead;
                zmq_send(responder, buffer, sizeof(buffer), 0);
                break;
                
        }
    }
    pthread_exit(NULL);
}

int usage()
{
    fprintf(stderr, "usage: zserv [iface] [reb-id]\n");
    return -1;
}

int main(int argc, char **argv)
{   
    pthread_t   reg_task;
    reg_args_t  reg_args;
    
#ifdef IMAGE_SERVICE 
    pthread_t   img_task;
    pthread_t   img_brd;
    image_t     *img;
#endif    

    if (argc < 3) return usage();
    
    reg_args.iface = argv[1];
    reg_args.id = strtoul(argv[2], NULL, 0);
    pthread_create(&reg_task, NULL, register_task, &reg_args);
    
#ifdef IMAGE_SERVICE 
    img = malloc(sizeof(image_t));
    img->iface = reg_args.iface;
    img->reb_id = reg_args.id;
    img->broadcast_data_ready_flag = 0;
    img->data = gige_data_init(reg_args.id, reg_args.iface);
    pthread_mutex_init(&(img->stripe_lock), NULL);
    pthread_create(&img_task, NULL, image_task, img);
    pthread_create(&img_brd, NULL, image_broadcaster, img);
#endif    
    
    pthread_join(reg_task, NULL);
    
    return 0;
}
